BP ELITE SAAS INSTITUTIONAL V5

Objectif:
Transformer le SaaS en plateforme type banque d'affaires / restructuring / private equity avec:
- projets par dossier d'investissement
- wizard BP très détaillé en 12 sections
- exports Excel top-tier
- exports PowerPoint IM / IC deck
- QoE pack détaillé
- restructuring pack
- data room par projet
- endpoints backend propres

FICHIERS A UPLOADER A LA RACINE GITHUB:
1. server.py
2. index.html
3. institutional_bp_engine.py
4. institutional_excel_builder.py
5. institutional_deck_builder.py
6. institutional_qoe_engine.py
7. institutional_restructuring_engine.py
8. project_schema.py
9. project_manager.py
10. module_wizards.py

NE PAS SUPPRIMER:
- build.py
- sheet_*.py
- debt_engine.py
- styles.py
- periods.py
- scenarios.py
- extractor.py
- financial_normalizer.py
- quality_checks.py
- requirements.txt
- runtime.txt
- .python-version
- nixpacks.toml

INSTALL:
1. Dézippe ce pack.
2. GitHub -> Add file -> Upload files.
3. Glisse les 10 fichiers à la racine.
4. Accepte "Replace existing files" pour server.py/index.html.
5. Commit changes.
6. Railway -> Redeploy latest commit.
7. Test: /health

PROMESSE PRODUIT:
- BP V1: 1h de setup client
- BP institutionnel: 2-6h selon complexité
- IM deck V1: 1-2h après extraction data
- QoE V1: 1-3h selon disponibilité des détails
- Restructuring pack: 2-4h avec dette et cash-flow

SORTIES:
- Detailed_BP_Institutional.xlsx
- QoE_Pack_Institutional.xlsx
- Restructuring_Pack.xlsx
- Investment_Memorandum.pptx
- IC_Committee_Pack.pptx
