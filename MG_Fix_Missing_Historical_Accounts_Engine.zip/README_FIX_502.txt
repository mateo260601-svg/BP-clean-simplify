FIX ERREUR 502 - historical_accounts_engine.py manquant

Erreur Railway actuelle:
ModuleNotFoundError: No module named 'historical_accounts_engine'

Action:
1. Ajouter historical_accounts_engine.py à la racine GitHub
2. Commit changes
3. Railway -> Clear Build Cache
4. Redeploy latest commit

Ne remplace pas server.py.
Ne supprime rien d'autre.
