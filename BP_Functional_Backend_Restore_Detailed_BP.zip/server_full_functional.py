import uuid
from pathlib import Path
from typing import Optional, Dict, Any

from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# --- Existing / legacy BP model builder ---
# This is the detailed BP engine you already had before the UI changes.
from build import build_model

# --- New document / deck modules ---
try:
    from extractor import extract_document
    from financial_normalizer import normalize_extracted_payload
    from quality_checks import run_quality_checks
    from deck_generator import generate_deck
    from financial_schema import NormalizedFinancials
except Exception:
    extract_document = None
    normalize_extracted_payload = None
    run_quality_checks = None
    generate_deck = None
    NormalizedFinancials = None

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
OUTPUT_DIR = BASE_DIR / "outputs"
UPLOAD_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)

app = FastAPI(title="MG Advisory Investment Banking Suite", version="3.1-full")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

OUTPUT_FILES: Dict[str, Path] = {}
LAST_FINANCIALS: Dict[str, Any] = {}
LAST_CONFIG: Dict[str, Dict[str, Any]] = {}

VALID_KEYS = {
    "JRC-MATEO-2025",
    "JRC-JAUFRE-2025",
    "JRC-OZAN-2025",
    "JRC-DEV-LOCAL",
    "MG-ACCESS-2025",
    "BP-ELITE-2025",
}

class LoginRequest(BaseModel):
    license_key: str

class GenerateRequest(BaseModel):
    license_key: str
    company_name: Optional[str] = "Target Company"
    config: Optional[Dict[str, Any]] = None
    extracted_payload: Optional[Dict[str, Any]] = None


def clean_key(key: str) -> str:
    return (key or "").strip().upper().replace("–", "-").replace("—", "-").replace("−", "-").replace(" ", "")


def check_license(key: str):
    key = clean_key(key)
    # During beta, accept all JRC-* keys so you are not blocked during testing.
    if key in VALID_KEYS or key.startswith("JRC-"):
        return key
    raise HTTPException(status_code=401, detail="Invalid license key")


@app.get("/", response_class=HTMLResponse)
def index():
    index_path = BASE_DIR / "index.html"
    if index_path.exists():
        return index_path.read_text(encoding="utf-8")
    return "<h1>MG Advisory Investment Banking Suite</h1>"

# Avoid /app 404: your old frontend sometimes redirects there.
@app.get("/app", response_class=HTMLResponse)
def app_page():
    return index()


@app.post("/api/auth/login")
def login(payload: LoginRequest):
    key = check_license(payload.license_key)
    return {"ok": True, "license": key}


def _num(v, default=0.0):
    try:
        if v is None or v == "":
            return default
        return float(v)
    except Exception:
        return default


def _nested_get(d: Dict[str, Any], path: str, default=None):
    cur = d or {}
    for part in path.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return default
        cur = cur[part]
    return cur


def config_from_payload(payload: GenerateRequest) -> Dict[str, Any]:
    """
    Converts the new SaaS UI payload into the legacy detailed BP engine format.
    The old build.py expects a flat config with base_revenue, gross_margin, etc.
    """
    raw = payload.config or {}

    company_name = (
        payload.company_name
        or _nested_get(raw, "company.name")
        or raw.get("company_name")
        or "Target Company"
    )
    currency = _nested_get(raw, "company.currency") or raw.get("currency") or "EUR"
    sector = _nested_get(raw, "company.sector") or raw.get("business_type") or "industrial"

    base_revenue = (
        _nested_get(raw, "revenue.base_revenue")
        or raw.get("base_revenue")
        or 202000
    )
    # If UI sends revenue in absolute EUR, convert to EURk for the detailed BP workbook.
    base_revenue = _num(base_revenue, 202000)
    if base_revenue > 5_000_000:
        base_revenue = base_revenue / 1000

    debt_tranches = _nested_get(raw, "debt.tranches") or raw.get("tranches") or []
    total_debt = 0
    if isinstance(debt_tranches, list):
        for t in debt_tranches:
            if isinstance(t, dict):
                total_debt += _num(t.get("amount"), 0)
    if total_debt > 5_000_000:
        total_debt = total_debt / 1000

    capex_raw = raw.get("capex") if isinstance(raw.get("capex"), dict) else {}
    maintenance_capex = _nested_get(raw, "capex.maintenance") or capex_raw.get("maint_capex") or capex_raw.get("maintenance") or 11500
    expansion_capex = _nested_get(raw, "capex.expansion") or capex_raw.get("expan_capex") or capex_raw.get("expansion") or 0
    if _num(maintenance_capex) > 5_000_000:
        maintenance_capex = _num(maintenance_capex) / 1000
    if _num(expansion_capex) > 5_000_000:
        expansion_capex = _num(expansion_capex) / 1000

    cfg = {
        "company_name": company_name,
        "currency": currency,
        "business_type": sector,
        "scenarios": raw.get("scenarios", "base"),
        "n_years": int(_num(raw.get("n_years"), 5)),
        "start_year": int(_num(_nested_get(raw, "revenue.start_year") or raw.get("start_year"), 2026)),
        "actuals_months": int(_num(raw.get("actuals_months"), 0)),
        "opening_cash": _num(raw.get("opening_cash"), 18700),
        "base_revenue": base_revenue,
        "revenue_growth": _num(_nested_get(raw, "revenue.volume_growth") or raw.get("revenue_growth"), 0.073),
        "gross_margin": _num(_nested_get(raw, "costs.gross_margin") or raw.get("gross_margin"), 0.391),
        "ebitda_margin": _num(_nested_get(raw, "costs.ebitda_margin") or raw.get("ebitda_margin"), 0.229),
        "dso": _num(_nested_get(raw, "nwc.dso") or raw.get("dso"), 55),
        "dio": _num(_nested_get(raw, "nwc.dio") or raw.get("dio"), 40),
        "dpo": _num(_nested_get(raw, "nwc.dpo") or raw.get("dpo"), 55),
        "tax_rate": _num(_nested_get(raw, "tax.rate") or raw.get("tax_rate"), 0.25),
        "inflation": _num(raw.get("inflation"), 0.025),
        "price_per_mt": _num(raw.get("price_per_mt"), 2000),
        "capacity_mt": _num(raw.get("capacity_mt"), 72000),
        "capex": {
            "opening_ppe": _num(capex_raw.get("opening_ppe"), 85000),
            "maint_capex": _num(maintenance_capex, 11500),
            "expan_capex": _num(expansion_capex, 0),
            "useful_life": int(_num(_nested_get(raw, "capex.useful_life") or capex_raw.get("useful_life"), 15)),
        },
        "debt": {
            "total_debt": total_debt or _num(_nested_get(raw, "debt.total_debt") or raw.get("total_debt"), 201000),
            "interest_rate": _num(_nested_get(raw, "debt.interest_rate") or raw.get("interest_rate"), 0.075),
            "tranches": debt_tranches,
        },
    }
    return cfg


def config_from_financials(financials: Any, fallback_company="Target Company") -> Dict[str, Any]:
    cfg = config_from_payload(GenerateRequest(license_key="JRC-DEV-LOCAL", company_name=fallback_company, config={}))
    try:
        latest = financials.periods[-1]
        cfg["company_name"] = financials.company_name or fallback_company
        cfg["currency"] = financials.currency or "EUR"
        if latest.revenue:
            cfg["base_revenue"] = latest.revenue / 1000 if latest.revenue > 5_000_000 else latest.revenue
        if latest.ebitda and latest.revenue:
            cfg["ebitda_margin"] = latest.ebitda / latest.revenue
        if latest.gross_profit and latest.revenue:
            cfg["gross_margin"] = latest.gross_profit / latest.revenue
        if latest.cash:
            cfg["opening_cash"] = latest.cash / 1000 if latest.cash > 5_000_000 else latest.cash
        if latest.debt:
            cfg["debt"]["total_debt"] = latest.debt / 1000 if latest.debt > 5_000_000 else latest.debt
        if latest.capex:
            cfg["capex"]["maint_capex"] = latest.capex / 1000 if latest.capex > 5_000_000 else latest.capex
    except Exception:
        pass
    return cfg


@app.post("/api/import")
async def import_file(license_key: str = Form(...), file: UploadFile = File(...)):
    key = check_license(license_key)
    if extract_document is None:
        raise HTTPException(status_code=500, detail="Document extraction module not available")

    file_id = str(uuid.uuid4())
    safe_name = (file.filename or "uploaded_file").replace("/", "_").replace("\\", "_")
    path = UPLOAD_DIR / f"{file_id}_{safe_name}"
    path.write_bytes(await file.read())

    extracted = extract_document(str(path))
    financials = normalize_extracted_payload(extracted, company_name=safe_name.rsplit(".", 1)[0])
    financials = run_quality_checks(financials)
    LAST_FINANCIALS[key] = financials
    LAST_CONFIG[key] = config_from_financials(financials, fallback_company=safe_name.rsplit(".", 1)[0])

    return {
        "ok": True,
        "file_id": file_id,
        "filename": safe_name,
        "financials": financials.model_dump() if hasattr(financials, "model_dump") else {},
    }


@app.post("/api/generate")
def generate_excel(payload: GenerateRequest):
    key = check_license(payload.license_key)

    if payload.config:
        cfg = config_from_payload(payload)
    elif key in LAST_CONFIG:
        cfg = LAST_CONFIG[key]
    elif key in LAST_FINANCIALS:
        cfg = config_from_financials(LAST_FINANCIALS[key], fallback_company=payload.company_name or "Target Company")
    else:
        cfg = config_from_payload(payload)

    file_id = str(uuid.uuid4())
    safe_company = "".join(ch for ch in cfg.get("company_name", "Company") if ch.isalnum() or ch in " _-").strip() or "Company"
    output = OUTPUT_DIR / f"{file_id}_{safe_company}_Detailed_BP_Model.xlsx"

    build_model(cfg, str(output))
    OUTPUT_FILES[file_id] = output

    return {
        "ok": True,
        "file_id": file_id,
        "filename": output.name,
        "engine": "legacy_detailed_bp_build_model",
        "config_used": cfg,
    }

# Alias for future buttons / old code
@app.post("/api/generate_bp")
def generate_bp(payload: GenerateRequest):
    return generate_excel(payload)


@app.post("/api/generate_deck")
def generate_im_deck(payload: GenerateRequest):
    key = check_license(payload.license_key)
    if generate_deck is None:
        raise HTTPException(status_code=500, detail="Deck generation module not available")

    financials = LAST_FINANCIALS.get(key)
    if not financials:
        # Build minimal financials from demo config if user has not uploaded yet.
        if normalize_extracted_payload and run_quality_checks:
            demo = {"source_type": "demo", "text": "FY2024 Revenue 202000000 EBITDA 42300000 Cash 18700000 Debt 201000000 Capex 11500000 Free Cash Flow 9500000"}
            financials = run_quality_checks(normalize_extracted_payload(demo, company_name=payload.company_name or "Target Company"))
        else:
            raise HTTPException(status_code=400, detail="Upload financials first")

    file_id = str(uuid.uuid4())
    output = OUTPUT_DIR / f"{file_id}_MG_Advisory_IM_Deck.pptx"
    generate_deck(financials, str(output))
    OUTPUT_FILES[file_id] = output
    return {"ok": True, "file_id": file_id, "filename": output.name}


@app.get("/api/download/{file_id}")
def download(file_id: str):
    path = OUTPUT_FILES.get(file_id)
    if not path or not path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(str(path), filename=path.name)

@app.get("/api/download_deck/{file_id}")
def download_deck(file_id: str):
    return download(file_id)

@app.get("/health")
def health():
    return {"ok": True, "service": "MG Advisory Investment Banking Suite", "version": "3.1-full"}
