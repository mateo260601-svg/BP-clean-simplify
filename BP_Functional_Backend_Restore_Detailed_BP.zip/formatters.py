def apply_elite_workbook_formatting(output_path):
    """
    Compatibility hook for the legacy detailed BP builder.
    The workbook is already formatted inside build.py; this no-op prevents warnings.
    """
    return output_path
